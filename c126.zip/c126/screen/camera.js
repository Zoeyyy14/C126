import * as React from 'react';
import { Text, View, StyleSheet, Image, Button, Platform } from 'react-native';
import * as ImagePicker from "expo-image-picker"
import * as Permissions from "expo-permissions"

export default class PickImage extends React.Component{
  state={
    image:null
  }
  render(){
    let {image}=this.state
    return(
      <View style={{flex:1,alignItems:"center",justifyContent:"center",width:200,height:100,}}>
      <Button tittle="Pick An Image From Camera Roll"/>
      </View>
    )
  }
}